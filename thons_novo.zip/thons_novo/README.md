# Site de Apostas Esportivas

Desenvolvedores:

1. Heloísa Ribeiro
2. Nickolas Minder
3. Oziel Paixão
4. Sérgio Gentile
5. Thaís Cristina

Curso: Sistemas para Internet

Ciclo: 3

Matéria: Java Script - Prof. Felipe 