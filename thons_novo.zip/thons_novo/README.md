# Site de Apostas Esportivas

Desenvolvedores:

1. Heloísa Ribeiro
2. Maria Fernanda
3. Michelle Baraçal
4. Nickolas Minder
5. Oziel Paixão
6. Sérgio Gentile
7. Thaís Cristina

Curso: Sistemas para Internet

Ciclo: 3

Matéria: Java Script - Prof. Felipe 