//ARRUMAR E TIRAR DO INDEX
 
  // window.alert('Você está preparado para APOSTAR???')
  // window.alert('ATENÇÃO: Não nós responsabilizamos por perdas financeiras!!!')
  // window.confirm('Digite OK se você for maior de 18 anos?')
  // window.alert('Bem vindo(a) e boa sorte!')

document.querySelector(".ativarForm").addEventListener("click", function() {
    document.querySelector(".meuForm").style.display = "block";
    document.querySelector(".ativarForm").style.display = "none"; 
});

document.querySelector(".apostar").addEventListener("click", function(event) {
    event.preventDefault();
    var time = document.querySelector("#time").value;
    var mensagem = document.querySelector(".mensagem");
    mensagem.style.color = "green";
    mensagem.style.display = "block"; 
    mensagem.style.backgroundColor = "#f9f9f9"; 
    mensagem.style.border = "1px solid #ddd"; 
    mensagem.style.padding = "10px"; 
    mensagem.style.width = "200px"; 
    mensagem.style.margin = "0 auto"; 
    mensagem.style.borderRadius = "5px"; 
    mensagem.style.display = "block";
    mensagem.innerHTML = "Você ganhou apostando no " + time;
    document.querySelector(".mensagem").innerHTML = "Você ganhou apostando no " + time;
});

document.querySelector(".cancelar").addEventListener("click", function(event) {
    event.preventDefault();
    document.querySelector(".meuForm").style.display = "none";
    document.querySelector(".mensagem").style.display = "none";
    document.querySelector(".ativarForm").style.display = "block"; 
});
  
  