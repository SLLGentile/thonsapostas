//ARRUMAR E TIRAR DO INDEX
 
  window.alert('Você está preparado para APOSTAR???')
  window.alert('ATENÇÃO: Não nós responsabilizamos por perdas financeiras!!!')
  window.confirm('Digite OK se você for maior de 18 anos?')
  window.alert('Bem vindo(a) e boa sorte!')
  
  